﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking.Match;
using UnityEngine.UIElements;
using Image = UnityEngine.UI.Image;
using Random = System.Random;
using DG.Tweening;
//[Serializable]
public class tank : MonoBehaviour
{
  //  Vector2 startPos = Vector2.zero;
  //  Vector2 endPos = Vector2.zero;
  //  Rect selectRect = new Rect();
    //public Transform camRig;
    private float SQ = G.SQ;
    
    private Collider2D C2D;
    [SerializeField] Collider2D menuC2D;

    public GameObject fogMask;

    public Transform effectsGroup;

    private const int F_NOCTRL	 = 0;
    private const int F_NOTASK	 = 5;
    private const int F_IDLE	 = 10;
    private const int F_ROTATE= 20;
    private const int F_MOVE	 = 30;
    private const int F_MEETTARGET	 = 40;
    private const int F_CAPTURE	 = 50;

    public int mySide = 0;
    
    private int fase	= -1;
    private int faseNext	= F_NOTASK;
    private float fcounter = 0;
    
    
    public GameObject chassis;
    //public SpriteRenderer basis;   
    public GameObject gun1;
    //public SpriteRenderer gun2;
    //public SpriteRenderer addon;

    [SerializeField] GameObject myBase;
    [SerializeField] GameObject myHead;

    private Animator gun1Anim;
        
    /*
    public Image chassisSrc;
    public Image basisSrc;   
    public Image gun1Src;
    public Image gun2Src;
    public Image addonSrc;
*/
    
    private Vector2 prevPoint;
    private Vector2 nextPoint;
    
    private Vector2 targetPoint;
    private building target;
    
    private GameObject headTarget;  // Head target
    private bool headHaveTarget=false;
    private float headTargetSearchCounter=0.2f;
        
    private Vector2 dir;
    private int dirN;
    private int tryingDirN=99;
    private float currAngle;
    private float newAngle;

    private float headNewAngle;
    

    private float accelDist = 1;
    private float speed = 30;
    public float speedMax = 30;

    private Vector2 maxVelocity;
    
    
    Vector2[] aDir = new Vector2[4];
    public Vector2[] tryDir = new Vector2[4];
    private bool moveX;
   
    Camera cam;
    private bool selected;
    public GameObject selectorObj;
    public GameObject selectorObjGroup;
    public tankMenu tankmenu;
    public GameObject explo;

    int task = 0; // capture bases etc  
    int nextTask = 0; 
    
   // [SerializeField] database db;
   private float health=100;
    private float fireRange = 0;

    private bool destroyed = false;

    public tankMoveHelper moveHelper;
    // Start is called before the first frame update
    void Start()
    {
        //EffectsGroup = GameObject.FindGameObjectWithTag("Effects Layer").GetComponent<Transform>();

        dir = new Vector2(0,-1);
        
        aDir[0]=new Vector2(1,0);
        aDir[1]=new Vector2(0,1); 
        aDir[2]=new Vector2(-1,0);
        aDir[3]=new Vector2(0,-1);
        
        cam = Camera.main;
        
        selectorObj = Instantiate(selectorObj, selectorObjGroup.transform);    
        selectorObj.SetActive(false);
        
        selected = false;
        
        SetToSqCenter();
        prevPoint = new Vector2(transform.position.x,transform.position.y);
        nextPoint = new Vector2(transform.position.x,transform.position.y);
        
        accelDist = 0.9f * (SQ * 0.5f);
        
        C2D = GetComponent<Collider2D>();

        nextTask = G.CAPTURE_FACTORIES;
        currAngle = transform.eulerAngles.z;

        dirN = 99;
        tryingDirN = 99;
    }

    public void SetEquipment(chassis chassis_,gun gun1_)
    {
        
        //Debug.Log("* * * chassis name: "+chassis_.name+" / gun1 name: "+gun1_.name);
        chassis = Instantiate(chassis_.prefab,myBase.transform);
        
        gun1 = Instantiate(gun1_.prefab,myHead.transform);
        //gun1.GetComponent<wpnPrefab>().bullet = gun1_.bullet;
        //gun1.GetComponent<wpnPrefab>().bulletLayer=GameObject.FindGameObjectWithTag("Bullet Layer");
        gun1.GetComponent<wpnPrefab>().parent = GetComponent<tank>();  
        gun1Anim = gun1.GetComponent<Animator> ();
        gun1Anim.SetBool("firing", false);
        
        //SetMySide((Mathf.Round(UnityEngine.Random.Range(0.0f,1.0f))>0.5f?G.WarSides.ENEMY:G.WarSides.PLAYER));
        
       // Debug.Log("gunAnim "+gun1Anim);

        speedMax = chassis_.speed[0];
        fireRange = gun1_.range*G.SQ;

        if (fogMask!=null)
        {
            float sc = 2.0f * fogMask.transform.localScale.x * (gun1.GetComponent<wpnPrefab>().bulletRange + 1);
           // fogMask.transform.localScale = new Vector3(sc, sc, 1.0f);
            fogMask.transform.DOScale(sc, 1);
        }
    }
    
    private void Awake()
    {
      
    }

    // Update is called once per frame
    void Update()
    {
        if (destroyed) return;

        if (mySide == G.PLAYER_SIDE)
        {
            fogMask.transform.position = transform.position;
            selectorObj.transform.position = cam.WorldToScreenPoint(transform.position);
        }

        if (fase != faseNext || fcounter<0) 
        {
            fcounter = 0.0f;
            fase = faseNext;

            //Debug.Log(fase + " - ");
        }
        else 
        {
            fcounter += Time.deltaTime;				
        }
		
        switch (fase) {
            //case F_NOCTRL: 	FNoCtrl();
            case F_NOTASK: 	    FNotask(); break;
            case F_IDLE: 	    FIdle(); break;
            case F_ROTATE: 	    FRotate(); break;
            case F_MOVE: 	    FMove(); break;
            case F_MEETTARGET: 	FMeetTarget(); break;
            case F_CAPTURE:     FCapture();
                break;
            
			
        }	

        Vector3 v1 = transform.position;
        v1.z = -1;
        Vector3 v2 = nextPoint;
        v2.z = -1;
       // Debug.DrawLine(v1,v2,Color.green);

        if (target != null)
        {
            Debug.DrawLine(transform.position, targetPoint, Color.gray);
            Debug.DrawLine(transform.position, V3V2(transform.position)+SQ*DirToPoint(targetPoint), Color.cyan);
            Debug.DrawLine(transform.position, nextPoint, Color.magenta);
            // Debug.DrawRay(myHead.transform.position,V2V3(Vector2.Angle(Vector2.right,target.transform.position-myHead.transform.position)),Color.red);


        }
    }
    
    private void FixedUpdate()
    {
        HeadControl();     
    }

    void FNotask()
    {
        if (fcounter == 0)
        {
            if (ChooseTarget())
            {
                task = nextTask;
                faseNext = F_IDLE;
                //nextFase = ChooseTarget();
            }
        }
        

        if (fcounter > 1.0f)
        {
            fcounter = -1;
        }
    }
    
    
    void FIdle()
    {
        if (fcounter == 0) 
        {

            SetToSqCenter();



            if (TargetIsActual())
            {
                nextPoint = ChooseNextPoint();

                //Debug.Log("NP: " + nextPoint + " / TP: " + transform.position);
                {
                    faseNext = F_ROTATE;
                }
            }
            else
                faseNext = F_NOTASK;

        }

        if (fcounter > 1.0f)
        {
            fcounter = -1;
        }
        //Debug.Log("NP: "+nextPoint+" / TP: "+transform.position);

    }

    bool TargetIsActual()
    {
        if (target != null)
        {
            if (target.GetComponent<building>().mySide == mySide)
            {
                target = null;
                return false;
            }

            return true;
        }
        /*
        if (target == null)
            if (ChooseTarget())
            {
                //Debug.Log("nextPoint " + nextPoint);
                if (Vector2.Distance(transform.position, nextPoint) > 1.0f)
                    return true;

                return false;
            }
            else return false;
        */
        return false;
    }

    void FRotate()
    {
        if (fcounter == 0) 
        {
            //Debug.Log("FRotate nextPoint " + nextPoint);

        }

        newAngle =Mathf.MoveTowardsAngle(myBase.transform.eulerAngles.z, DirToAngle(tryDir[dirN]),3);
        myBase.transform.eulerAngles = new Vector3(0,0,newAngle);
        
        if (Mathf.Abs(myBase.transform.eulerAngles.z - DirToAngle(tryDir[dirN])) < 5)
        {
            faseNext = F_MOVE;
            myBase.transform.eulerAngles = new Vector3(0,0,DirToAngle(tryDir[dirN]));
        }
        
    }
    
    void PrepareToMove()
    {

    }
    void FAcceleration()
    {
        if (fcounter == 0)
        {
            if (moveX)
                transform.DOMoveX(transform.position.x+dir.x*SQ,1.0f);
            else
                transform.DOMoveY(transform.position.y+dir.y*SQ,1.0f);
        }

    }

    void FMove()
    {
        if (fcounter == 0) 
        {
            prevPoint = transform.position;
        }

        Vector2 lastXY= new Vector2();
        lastXY = transform.position;

        speed = CalcSpeed();
        
        transform.position = Vector2.MoveTowards(transform.position, nextPoint, Time.deltaTime * speed);

        if (Vector2.Distance(transform.position, nextPoint) < speed * Time.deltaTime)
        {
            transform.position = nextPoint;
            speed = 0.0f;
            faseNext = (Vector2.Distance(nextPoint, targetPoint) < 1.0f ? F_MEETTARGET : F_IDLE);

            //Debug.Log("FMove nextPoint " + nextPoint);

            if (Vector2.Distance(nextPoint,prevPoint)>SQ*2)
            {
                dirN = 99;
                //tryingDirN = 99;
            }
            else
            {
                //tryingDirN = dirN;
            }

            return;
        }
        /*
        RaycastHit2D hit = Physics2D.Raycast(transform.position, dir, SQ*0.95f, LayerMask.GetMask("solid"));

        if (hit.collider != null || moveHelper.SqIsEmpty(transform.position.x+dir.x*SQ,transform.position.y+dir.y*SQ))
        {
            nextPoint = GetClosestSqCenter();
            //transform.position = nextPoint;
            return;
        }*/
        if (moveHelper.SqIsEmpty(transform.position.x+dir.x*SQ,transform.position.y+dir.y*SQ))
        {
            nextPoint = GetClosestSqCenter();
            
            return;
        }

        if (dirN > 0)
            if (moveX)
            {
                if (CheckCrossSQ(lastXY.x, transform.position.x))
                {
                    //Debug.Log("FMove Check dir " + tryDir[dirN - 1]);
                    if (Physics2D.Raycast(transform.position, tryDir[dirN - 1], SQ * 0.95f, LayerMask.GetMask("solid")).collider == null)
                    {
                        nextPoint = GetClosestSqCenter();
                        tryingDirN = dirN - 1;
                        //Debug.Log("FOUND!");
                    }
                }
            }
            else
            {
                if (CheckCrossSQ(lastXY.y, transform.position.y))
                {
                    //Debug.Log("FMove Check dir " + tryDir[dirN - 1]);
                    if (Physics2D.Raycast(transform.position, tryDir[dirN - 1], SQ * 0.95f, LayerMask.GetMask("solid")).collider == null)
                    {
                        nextPoint = GetClosestSqCenter();
                        tryingDirN = dirN - 1;
                        //Debug.Log("FOUND!");
                    }

                }
            }
        
        

            if (target!=null)
            if (moveX)
            {
                if (CheckCrossSQ(lastXY.x, transform.position.x))
                {
                    if (!CheckCrossSQ(targetPoint.x, transform.position.x))
                    {
                        if (Physics2D.Raycast(transform.position, DirToPoint(targetPoint), SQ * 0.95f, LayerMask.GetMask("solid")).collider == null)
                            nextPoint = GetClosestSqCenter();
                    }
                }
            }
            else
            {
                if (CheckCrossSQ(lastXY.y, transform.position.y))
                {
                    if (!CheckCrossSQ(targetPoint.y, transform.position.y))
                        if (Physics2D.Raycast(transform.position, DirToPoint(targetPoint), SQ*0.95f, LayerMask.GetMask("solid")).collider==null)
                            nextPoint = GetClosestSqCenter();

                }
            }

    }

    void FMeetTarget()
    {
        if (fcounter == 0)
        {
            //Debug.Log("MEET TARGET");
            //target = null;
            //targetPoint.Set(0.0f,0.0f);
            faseNext = F_CAPTURE;
            dirN = 99;
        }
        
        

       
    }

    void FCapture()
    {
        if (fcounter == 0)
        {
            if (target.mySide == mySide)
            {
                faseNext = F_NOTASK;               
                target = null;
                targetPoint.Set(0.0f,0.0f);
                
                return;
            }
            
        }

        if (fcounter > 3.0f)
        {
            if (target != null)
            {

                target.CaptureMe(mySide);
               
                target = null;
            }
            
            targetPoint.Set(0.0f,0.0f);
            faseNext = F_NOTASK;
        }
            
        
    }
    
    Vector2 ChooseNextPoint()
    {
        //Debug.Log("1 ChooseNextPoint nextPoint=" + nextPoint + " / tryingDirN = " + tryingDirN + " / dirN = " + dirN + " / dir = " + dir);
        if (tryingDirN < 4)
           dirN = tryingDirN;
        else
        {
            dirN += 1;

            if (dirN > 3)
            {
                //dirN = 0;
                FillDirectionsArray();
            }
        }

        tryingDirN = 99;

        Vector2 pnt = new Vector2();
        
        dir = tryDir[dirN];
        pnt.x = transform.position.x + dir.x * SQ * UnityEngine.Random.Range(3, 10);
        pnt.y = transform.position.y + dir.y * SQ * UnityEngine.Random.Range(3, 10);
        
        moveX = Mathf.Abs(dir.x) > 0.5f;

        //Debug.Log("2 ChooseNextPoint nextPoint=" + nextPoint + " / tryingDirN = " + tryingDirN + " / dirN = " + dirN + " / dir = " + dir);

        return pnt;
    }

    void FillDirectionsArray()
    {/*
        if (fcounter == 0)
        {
            dirN = 0;
        }	
        */
        //Debug.Log(obj);

        

        dirN = 0;

        Vector2 vec = new Vector2();
        vec = targetPoint - (new Vector2(transform.position.x,transform.position.y));

        if (target == null || Mathf.Abs(vec.x + vec.y) < SQ)
        {
            //Debug.Log(" !!! FillDirectionsArray NOTARGET !!!");
        }

        if (Mathf.Abs(vec.x) > Mathf.Abs(vec.y))
        {
            if (vec.x > 0)
            {
                tryDir[0] = aDir[0];
                tryDir[2] = aDir[2];
            }
            else
            {
                tryDir[0] = aDir[2];
                tryDir[2] = aDir[0];
            }

            if (vec.y > 0)
            {
                tryDir[1] = aDir[1];
                tryDir[3] = aDir[3];
            }

            else
            {
                tryDir[1] = aDir[3];
                tryDir[3] = aDir[1];
            }
               
        }
        else
        {
            if (vec.y > 0)
            {
                tryDir[0] = aDir[1];
                tryDir[2] = aDir[3];
            }
            else
            {
                tryDir[0] = aDir[3];
                tryDir[2] = aDir[1];
            }

            if (vec.x > 0)
            {
                tryDir[1] = aDir[0];
                tryDir[3] = aDir[2];
            }

            else
            {
                tryDir[1] = aDir[2];
                tryDir[3] = aDir[0];
            }
        }

         //Debug.Log("NEW tryDir0 " + tryDir[0]);

        //dir = tryDir[0];
        //target = obj;
        //nextPoint.x += dir.x * 24*UnityEngine.Random.Range(1,5);
        //nextPoint.y += dir.y * 24*UnityEngine.Random.Range(1,5);

        //moveX = Mathf.Abs(dir.x) > 0;

        //faseNext = F_MOVE;
    }


    void chooseNewPoint()
    {
        SetToSqCenter();
        
        Vector2[] scr = new Vector2[4];
        
        scr[0]=new Vector2(1,0);
        scr[1]=new Vector2(0,1); 
        scr[2]=new Vector2(-1,0);
        scr[3]=new Vector2(0,-1);

        int i = 0;
        
        do
        {
            i = Mathf.FloorToInt(UnityEngine.Random.Range(0.0f, 3.9f));

        } while (dir==scr[i]);

        dir = scr[i];

        nextPoint.x += dir.x * 24*UnityEngine.Random.Range(1,5);
        nextPoint.y += dir.y * 24*UnityEngine.Random.Range(1,5);
               
    }

    void SetToSqCenter()
    {
        //RB.velocity = new Vector2();
        
        transform.position = new Vector2(Mathf.Floor(transform.position.x / 24.0f) * 24.0f + 12.0f,Mathf.Floor(transform.position.y / 24.0f) * 24.0f + 12.0f);
        
    }

    bool InSqCenter()
    {
        return (Vector2.Distance(transform.position, GetClosestSqCenter()) < 1.0f);

    }

    Vector2 GetClosestSqCenter()
    {
        return (new Vector2(Mathf.Floor(transform.position.x / 24.0f) * 24.0f + 12.0f,Mathf.Floor(transform.position.y / 24.0f) * 24.0f + 12.0f));
    }

    Vector2 GetClosestSqCenter(Vector2 pos)
    {
        return (new Vector2(Mathf.Floor(pos.x / 24.0f) * 24.0f + 12.0f, Mathf.Floor(pos.y / 24.0f) * 24.0f + 12.0f));
    }

    bool CheckCrossSQ(Vector2 pos1 , Vector2 pos2)
    {
        if (Mathf.FloorToInt(pos1.x / SQ) != Mathf.FloorToInt(pos2.x / SQ) ||
            Mathf.FloorToInt(pos1.y / SQ) != Mathf.FloorToInt(pos2.y / SQ))
            return true;

        return false;
    }
    
    bool CheckCrossSQ(float pos1 , float pos2)
    {
        if (Mathf.FloorToInt(pos1 / SQ) != Mathf.FloorToInt(pos2 / SQ))
            return true;

        return false;
    }

    void CheckMouseClick()
    {
        
        if (Input.GetButtonDown("Fire1"))
        {
            //Debug.Log("sel");
            
               
            if (menuC2D==Physics2D.OverlapPoint(Input.mousePosition, LayerMask.GetMask("UI")))
            {
                //Debug.Log("Clicked to menu "+Input.mousePosition);
            }
            else
            if (C2D==Physics2D.OverlapPoint(cam.ScreenToWorldPoint(Input.mousePosition), LayerMask.GetMask("units")))  
            {
                //selectorObj();
            }
            else
            {
                UnSelect();
            }
                

        }
    }

    public void Select()
    {
        if (!selected)
        {
            selected = true;
            selectorObj.SetActive(selected);
        }
            
    }

    public void UnSelect()
    {
        selected = false;
        selectorObj.SetActive(selected);
    }

    public void SetTask(int _task)
    {
        nextTask = _task;
       // //Debug.Log("my task is "+task);
    }

    bool ChooseTarget()
    {
        bool ret = false;

        switch (nextTask)
        {
            case G.CAPTURE_BASES:
                ret=ChooseBaseForCapture();
                break;
            case G.DESTROY_ENEMIES:
                ret = ChooseEnemyForDestroy();
                break;           
            case G.CAPTURE_FACTORIES:
                ret =ChooseFactoryForCapture();
                break;          
            
        }

        /**

        if (ret) 
            nextPoint = ChooseNextPoint();
        else 
            nextPoint = GetClosestSqCenter();
        */
        

        return ret;
    }

    bool ChooseBaseForCapture()
    {
        return false;
    }
    bool ChooseEnemyForDestroy()
    {
        return false;
    }
    
    bool ChooseFactoryForCapture()
    {
        float dist = 999;
        building nearestObj=null;
        target = null;
        
        GameObject[] aObj = GameObject.FindGameObjectsWithTag("Factory");
        
        foreach (GameObject obj in aObj)
        {
            if (obj.GetComponent<building>().mySide != mySide)
            if (Vector2.Distance(transform.position, obj.transform.position)* obj.GetComponent<building>().GetAimerCount(mySide) < dist)
            {
                    dist = Vector2.Distance(transform.position, obj.transform.position);
                    nearestObj = obj.GetComponent<building>();     
            }
        }
       
        //Debug.Log("ChooseFactoryForCapture: "+nearestObj);
        if (nearestObj!=null)
        {
            target = nearestObj;
            targetPoint = target.transform.position;

            target.AddAimer(mySide);

            return true;
        }
        else
        {
           StopNow();
        }

        return false;
    }

    void StopNow()
    {
        nextPoint = GetClosestSqCenter();
        faseNext = F_IDLE;
    }

    float CalcSpeed()
    {
        if (Vector2.Distance(transform.position, prevPoint)<Vector2.Distance(prevPoint,nextPoint)*0.4)
        {
            if (Vector2.Distance(transform.position, prevPoint) < accelDist)
            {
                return speedMax*(Vector2.Distance(transform.position, prevPoint)) / accelDist+1.0f;
            } 
        }
        else
        {
            if (Vector2.Distance(transform.position, nextPoint) < accelDist)
            {
                return speedMax*(Vector2.Distance(transform.position, nextPoint)) / accelDist+1.0f;
            }           
            
        }

        return speedMax;
    }

    Vector2 DirToPoint(Vector2 vec)
    {
        Vector2 ret = new Vector2();
        
        if (Mathf.Abs(vec.x - transform.position.x) > Mathf.Abs(vec.y - transform.position.y))
        {
            if (vec.x > transform.position.x)
            {
                ret.x = 1;
            }
            else
            {
                ret.x = -1;
            }
        }
        else
        {
            if (vec.y > transform.position.y)
            {
                ret.y = 1;
            }
            else
            {
                ret.y = -1;
            }
        }

        return ret;
    }

    Vector2 V3V2(Vector3 vec3)
    {
        return new Vector2(vec3.x,vec3.y);
    }
    
    Vector3 V2V3(Vector2 vec3)
    {
        return new Vector3(vec3.x,vec3.y,0.0f);
    }
    
    float DirToAngle(Vector2 dir)
    {
        if (dir.y == 0)
        {
            if (dir.x > 0.5)
                return 0;
            if (dir.x < 0.5)
                return 180;
        }
        else
        if (dir.x == 0)
        {
            if (dir.y > 0.5)
                return 90;
            if (dir.y < 0.5)
                return 270;
        }

        return 0;
    }

    public void SetMySide(int side)
    {
        mySide = side;
        
        RecolorAll(G.GetSideColor(mySide));
        /*
        if (side == G.PLAYER_SIDE)
        {
            RecolorAll(Color.red);
        }
        else
        if (side == G.WarSides.ENEMY)
        {
            RecolorAll(Color.blue);
        }        */
    }

    void RecolorAll(Color col)
    {
        //chassis.color = col;
        chassis.GetComponent<passiveEquipPrefab>().spriteForColoring.color = col;
        gun1.GetComponent<wpnPrefab>().spriteForColoring.color = col;
        
    }

    void HeadControl()
    {
        if (headTargetSearchCounter > 0)
        {
            headTargetSearchCounter -= Time.fixedDeltaTime;            
        }        
        else
        {        
            headTarget=HeadFindTarget();
            headHaveTarget = (headTarget != null);
            
            if (!headHaveTarget)
            {
                headTargetSearchCounter = 0.25f;
            }
            else
            {
                headTargetSearchCounter = 1.0f;

                myHead.transform.eulerAngles = new Vector3(0, 0, Vector2.SignedAngle(Vector2.right, headTarget.transform.position - myHead.transform.position));
                gun1Anim.SetBool("firing", true);
            }
        }

        if (headTarget != null)
        {
            myHead.transform.eulerAngles =
                new Vector3(0, 0,
                    Vector2.SignedAngle(Vector2.right, headTarget.transform.position - myHead.transform.position));
            gun1Anim.SetBool("firing", true);
        }
        else
        {
            myHead.transform.eulerAngles = myBase.transform.eulerAngles;
                //new Vector3(0, 0,Vector2.SignedAngle(Vector2.right,myBase.transform.eulerAngles));
            headHaveTarget = false;
            headTargetSearchCounter = -1;
            gun1Anim.SetBool("firing", false);
        }
        
    }

    GameObject HeadFindTarget()
    {
        float dist = fireRange;
        GameObject nearestObj=null;
        
        
        GameObject[] aObj = GameObject.FindGameObjectsWithTag("Tank");
        
        foreach (GameObject obj in aObj)
        {
            if (obj.GetComponent<tank>().mySide != mySide)
                if (Vector2.Distance(transform.position, obj.transform.position) < dist)
                    if (!Physics2D.Linecast(transform.position, obj.transform.position, 1 << 10))
                {
                    
                    //Debug
                        dist = Vector2.Distance(transform.position, obj.transform.position);
                    nearestObj = obj;//.GetComponent<tank>();                   
                

                }
        }

        return nearestObj;
    }
   
    public bool Selected()
    {
        return selected;
    }

    public void SetDamage(float damage)
    {      

        health -= damage;
        //Debug.Log("Damage " + damage + " / Health " + health);

        if (health>0) return;

        health = 0.0f;
       
        GameObject o=Instantiate(explo, effectsGroup);
        o.transform.position = transform.position;

        if (target != null)
            target.GetComponent<building>().RemoveAimer(mySide);

       Destroy(gameObject, 1 * Time.deltaTime);
        destroyed = true;


        Destroy(selectorObj.gameObject);

        if (fogMask != null)
        {
            fogMask.transform.DOScale(0.001f, 3);
            Destroy(fogMask.gameObject, 3);
        }

    }

    public bool GetDestroyed()
    {
        return destroyed;
    }
}
